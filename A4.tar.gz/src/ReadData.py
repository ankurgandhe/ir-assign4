import sys 
import scipy
import scipy.sparse
import numpy 
import math 
# Read Transition matrix given in sparse format
def ReadTransitionMatrix(FileName):
    item=0
    i=[]
    n_i = {}
    j=[]
    data=[]
    try:
        for l in open(FileName):
            l=l.strip().split()
            doc_i = int(l[0])-1
            i.append(doc_i)
	    if doc_i not in n_i:
		n_i[doc_i] = 0
	    n_i[doc_i] = n_i[doc_i]+1
	
            j.append(int(l[1])-1)
            data.append(int(l[2]))

        maxN = max(max(i),max(j))+1
        print >> sys.stderr, "Number of Documents with out links:", len(n_i)
	for idx in range(len(i)):	
            if i[idx] not in n_i:
                print >> sys.stderr, i[idx],": 0"
                continue 
	    data[idx] = data[idx]/n_i[i[idx]]
	    #print >> sys.stderr, I[idx],":",n_i[I[idx]], 1./n_i[I[idx]]
        DocsAdded=0
        for doci in range(maxN):
            if doci not in n_i:
                for docj in range(maxN):
                    i.append(doci)
                    j.append(docj)
                    data.append(1./maxN)
                DocsAdded=DocsAdded+1
                print >> sys.stderr,"Added ",doci
        print >> sys.stderr, DocsAdded," docs added to T matrix with prob: ", 1./maxN
        I = numpy.asarray(i)
        J = numpy.asarray(j)
        maxN = max(max(I),max(J))+1
        Data = numpy.asarray(data)

        TransitionMatrix = scipy.sparse.coo_matrix((Data,(I,J)),shape = (maxN,maxN))
        return TransitionMatrix 

    except IOError as e:
        print "I/O error({0}): {1}".format(e.errno, e.strerror)
        return 0


#Given nrows, ncolumns, generate Teleportaion matrix in sparse format 
def GetTeleportationMatrix(nrows, ncols, N):
    i=[]
    j=[]
    data=[]
    for idx in range(nrows):
        i.append(idx)
        j.append(idx)
        data.append(1./N)
    I = numpy.asarray(i)
    J = numpy.asarray(j)
    Data = numpy.asarray(data)
    TeleportationMatrix = scipy.sparse.coo_matrix((Data,(I,J)),shape=(nrows,ncols))
    return TeleportationMatrix
    
def CreatePageRankMatrix(M,E,alpha):
    alpha = float(alpha)
    B  = (1. - alpha)*M + alpha * E 
    return B.transpose()

def GetPageRank(B,method):
    #Create page rank r , using give method :
    epsilon = 0.00
    iter = 0
    n_docs = int(B.get_shape()[0])
    r = numpy.ones((n_docs,1))/n_docs
    r = scipy.sparse.coo_matrix(r)
    #r = scipy.sparse.coo_matrix(([1],([0],[0])),shape=(n_docs,1))
    print >> sys.stderr, "initial vector is of shape: ", r.shape, "and sums to", r.sum()
    if method=="iterate":
        conv=False
        while not conv:
            rold = r
            r = B * rold
	    diff = numpy.sum(numpy.absolute((rold.todense() - r.todense())))
            if diff <=epsilon:
                conv=True
	    iter = iter+1
	    if iter%10==0:
		print >> sys.stderr, str(iter)+":",str(diff)
    print >> sys.stderr, str(iter)+":",str(diff)
    return r 
                  
           
def CheckSparseMatrix(M):
    M = M.todense()
    for i in range(len(M)):
        print >> sys.stderr, sum(M[ii])
